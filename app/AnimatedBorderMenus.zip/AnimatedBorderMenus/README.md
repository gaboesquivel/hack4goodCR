
Animated Border Menus
=========


[Article on Codrops]()

[Demo]()

Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is". 

[License](http://tympanus.net/codrops/licensing/)


[Created by Codrops](http://www.codrops.com)

Menu icons by [Shapemade](http://steadysets.com/)
Free-to-use icons for personal and commercial projects.

Social Icons by [http://www.entypo.com/](http://www.entypo.com/)
[License](http://creativecommons.org/licenses/by-sa/3.0/)

Media icons by [http://fortawesome.github.io/Font-Awesome/](http://fortawesome.github.io/Font-Awesome/license/)

Iconfonts created with [Fontastic](http://fontastic.me/) and [Icomoon](http://icomoon.io/app/)